from django.contrib import admin
from .models import Thread, Post
# Register your models here.
admin.site.register(Thread)
admin.site.register(Post)