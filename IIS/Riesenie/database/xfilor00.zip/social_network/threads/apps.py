from django.apps import AppConfig


class ThreadsConfig(AppConfig):
    name = 'threads'
